package com.example

import com.example.science.ScienceEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScienceEngineTest {

    @Test
    fun testMolarMassCalculation() {
        val (mass, breakdown) = ScienceEngine.calculateMolarMass("H2SO4")
        // H: 2 * 1.008 = 2.016, S: 32.06, O: 4 * 15.999 = 63.996 => ~98.072
        assertTrue(mass > 97.0 && mass < 99.0)
        assertEquals(3, breakdown.size)
    }

    @Test
    fun testKinematicsCalculation() {
        // u = 0, a = 9.8, t = 2 -> v = 19.6, d = 0.5 * 9.8 * 4 = 19.6
        val result = ScienceEngine.solveKinematics(0.0, 9.8, 2.0)
        assertEquals(19.6, result.finalVelocity, 0.01)
        assertEquals(19.6, result.displacement, 0.01)
    }

    @Test
    fun testPunnettSquare() {
        val punnett = ScienceEngine.calculatePunnettSquare("Bb", "Bb")
        assertEquals(2, punnett.grid.size)
        assertEquals(2, punnett.grid[0].size)
        assertTrue(punnett.phenotypicRatio.contains("3 Dominant : 1 Recessive"))
    }

    @Test
    fun testDnaTranscription() {
        val (mrna, aminoAcids) = ScienceEngine.transcribeAndTranslateDna("TAC")
        assertEquals("AUG", mrna)
        assertEquals("Met (Start)", aminoAcids.first())
    }
}
