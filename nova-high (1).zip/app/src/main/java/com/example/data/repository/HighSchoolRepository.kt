package com.example.data.repository

import com.example.data.database.AppDatabase
import com.example.data.model.Assignment
import com.example.data.model.Course
import com.example.data.model.LabReport
import com.example.data.model.StudyNote
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class HighSchoolRepository(private val database: AppDatabase) {

    val allCourses: Flow<List<Course>> = database.courseDao().getAllCourses()
    val allAssignments: Flow<List<Assignment>> = database.assignmentDao().getAllAssignments()
    val allLabReports: Flow<List<LabReport>> = database.labReportDao().getAllLabReports()
    val allStudyNotes: Flow<List<StudyNote>> = database.studyNoteDao().getAllStudyNotes()

    suspend fun seedInitialDataIfEmpty() = withContext(Dispatchers.IO) {
        if (database.courseDao().getCourseCount() == 0) {
            val sampleCourses = listOf(
                Course(
                    code = "CHEM-301",
                    title = "AP Chemistry",
                    teacher = "Dr. Eleanor Vance",
                    room = "Sci-204",
                    period = 1,
                    timeSlot = "08:15 - 09:10 AM",
                    currentGradePercent = 95.4,
                    letterGrade = "A",
                    colorHex = "#059669"
                ),
                Course(
                    code = "PHYS-201",
                    title = "AP Physics 1: Mechanics",
                    teacher = "Prof. Marcus Brody",
                    room = "Sci-108",
                    period = 2,
                    timeSlot = "09:15 - 10:10 AM",
                    currentGradePercent = 92.8,
                    letterGrade = "A-",
                    colorHex = "#2563EB"
                ),
                Course(
                    code = "MATH-401",
                    title = "AP Calculus BC",
                    teacher = "Mrs. Sarah Jenkins",
                    room = "Math-302",
                    period = 3,
                    timeSlot = "10:15 - 11:10 AM",
                    currentGradePercent = 97.2,
                    letterGrade = "A+",
                    colorHex = "#D97706"
                ),
                Course(
                    code = "BIO-202",
                    title = "Honors Molecular Biology",
                    teacher = "Dr. Arthur Pendelton",
                    room = "Sci-215",
                    period = 4,
                    timeSlot = "11:15 - 12:10 PM",
                    currentGradePercent = 94.0,
                    letterGrade = "A",
                    colorHex = "#10B981"
                ),
                Course(
                    code = "ENG-301",
                    title = "AP English Literature",
                    teacher = "Mr. Kenneth Clark",
                    room = "Hum-114",
                    period = 5,
                    timeSlot = "12:50 - 01:45 PM",
                    currentGradePercent = 91.5,
                    letterGrade = "A-",
                    colorHex = "#8B5CF6"
                ),
                Course(
                    code = "HIST-301",
                    title = "AP United States History",
                    teacher = "Ms. Rachel Green",
                    room = "Soc-201",
                    period = 6,
                    timeSlot = "01:50 - 02:45 PM",
                    currentGradePercent = 93.6,
                    letterGrade = "A",
                    colorHex = "#E11D48"
                )
            )
            database.courseDao().insertAllCourses(sampleCourses)
        }

        if (database.assignmentDao().getAssignmentCount() == 0) {
            val sampleAssignments = listOf(
                Assignment(
                    courseCode = "CHEM-301",
                    title = "Standard Acid-Base Titration Lab Writeup",
                    dueDate = "Tomorrow, 11:59 PM",
                    priority = "High",
                    isCompleted = false,
                    notes = "Include titration curve graph and calculate molarity of unknown HCl solution."
                ),
                Assignment(
                    courseCode = "PHYS-201",
                    title = "Kinematics 2D Projectile Problem Set #4",
                    dueDate = "Thursday, 8:15 AM",
                    priority = "High",
                    isCompleted = false,
                    notes = "Problems 14-28 on conservation of energy and launch angles."
                ),
                Assignment(
                    courseCode = "MATH-401",
                    title = "Taylor Series & Convergence Tests Worksheet",
                    dueDate = "Friday, 10:15 AM",
                    priority = "Medium",
                    isCompleted = false,
                    notes = "Review Ratio Test and Alternating Series error bounds."
                ),
                Assignment(
                    courseCode = "BIO-202",
                    title = "Punnett Square Mendelian Genetics Case Study",
                    dueDate = "Next Monday",
                    priority = "Low",
                    isCompleted = true,
                    notes = "Completed dihybrid cross analysis of Drosophila melanogaster."
                )
            )
            database.assignmentDao().insertAllAssignments(sampleAssignments)
        }

        if (database.labReportDao().getLabReportCount() == 0) {
            val sampleReports = listOf(
                LabReport(
                    title = "Spectrophotometric Determination of Iron in Cereal",
                    subject = "Chemistry",
                    date = "Oct 8, 2026",
                    hypothesis = "Beer-Lambert Law absorbance will exhibit a strictly linear relationship with concentration between 0.001M and 0.01M Fe3+.",
                    procedure = "Prepared 5 calibration standards with 1,10-phenanthroline. Measured absorbance at 510nm using spectrophotometer.",
                    observations = "Solution turned orange-red. Linear regression yielded R² = 0.998.",
                    conclusion = "Extracted iron content was 18.2 mg per 100g serving, conforming within 3% of manufacturer nutrition facts."
                ),
                LabReport(
                    title = "Conservation of Mechanical Energy on an Incline Air Track",
                    subject = "Physics",
                    date = "Oct 2, 2026",
                    hypothesis = "Gravitational potential energy mgh converts into kinetic energy 0.5mv² with under 5% dissipation from air friction.",
                    procedure = "Dual photogate setup placed 1.2m apart on a 15-degree frictionless air track.",
                    observations = "Photogate times averaged 0.042 seconds for glider flag passing point B.",
                    conclusion = "Total mechanical energy conserved within 2.1% experimental margin of error."
                )
            )
            database.labReportDao().insertAllLabReports(sampleReports)
        }

        if (database.studyNoteDao().getStudyNoteCount() == 0) {
            val sampleNotes = listOf(
                StudyNote(
                    title = "Organic Chemistry: Functional Groups Cheat Sheet",
                    subject = "Chemistry",
                    content = "Alcohols (-OH), Aldehydes (-CHO), Ketones (-C=O), Carboxylic Acids (-COOH), Esters (-COO-), Amines (-NH2). Intermolecular H-bonding increases boiling point."
                ),
                StudyNote(
                    title = "Cellular Respiration ATP Accounting",
                    subject = "Biology",
                    content = "Glycolysis yields 2 net ATP + 2 NADH in cytoplasm. Krebs Cycle produces 2 ATP + 6 NADH + 2 FADH2. Oxidative phosphorylation generates ~28-32 ATP via ATP synthase proton gradient."
                )
            )
            for (n in sampleNotes) {
                database.studyNoteDao().insertStudyNote(n)
            }
        }
    }

    suspend fun insertAssignment(assignment: Assignment) = withContext(Dispatchers.IO) {
        database.assignmentDao().insertAssignment(assignment)
    }

    suspend fun updateAssignment(assignment: Assignment) = withContext(Dispatchers.IO) {
        database.assignmentDao().updateAssignment(assignment)
    }

    suspend fun deleteAssignment(assignment: Assignment) = withContext(Dispatchers.IO) {
        database.assignmentDao().deleteAssignment(assignment)
    }

    suspend fun insertLabReport(report: LabReport) = withContext(Dispatchers.IO) {
        database.labReportDao().insertLabReport(report)
    }

    suspend fun deleteLabReport(report: LabReport) = withContext(Dispatchers.IO) {
        database.labReportDao().deleteLabReport(report)
    }

    suspend fun insertStudyNote(note: StudyNote) = withContext(Dispatchers.IO) {
        database.studyNoteDao().insertStudyNote(note)
    }

    suspend fun deleteStudyNote(note: StudyNote) = withContext(Dispatchers.IO) {
        database.studyNoteDao().deleteStudyNote(note)
    }
}
