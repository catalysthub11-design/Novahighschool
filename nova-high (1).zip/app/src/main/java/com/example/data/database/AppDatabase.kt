package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.AssignmentDao
import com.example.data.dao.CourseDao
import com.example.data.dao.LabReportDao
import com.example.data.dao.StudyNoteDao
import com.example.data.model.Assignment
import com.example.data.model.Course
import com.example.data.model.LabReport
import com.example.data.model.StudyNote

@Database(
    entities = [Course::class, Assignment::class, LabReport::class, StudyNote::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun courseDao(): CourseDao
    abstract fun assignmentDao(): AssignmentDao
    abstract fun labReportDao(): LabReportDao
    abstract fun studyNoteDao(): StudyNoteDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "nova_high_database"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
