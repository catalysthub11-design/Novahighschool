package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "courses")
data class Course(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val code: String,
    val title: String,
    val teacher: String,
    val room: String,
    val period: Int,
    val timeSlot: String,
    val currentGradePercent: Double,
    val letterGrade: String,
    val colorHex: String
)

@Entity(tableName = "assignments")
data class Assignment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val courseCode: String,
    val title: String,
    val dueDate: String,
    val priority: String, // "High", "Medium", "Low"
    val isCompleted: Boolean = false,
    val notes: String = ""
)

@Entity(tableName = "lab_reports")
data class LabReport(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val subject: String, // "Chemistry", "Physics", "Biology", "Earth Science"
    val date: String,
    val hypothesis: String,
    val procedure: String,
    val observations: String,
    val conclusion: String
)

@Entity(tableName = "study_notes")
data class StudyNote(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val subject: String,
    val content: String,
    val audioGenerated: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
