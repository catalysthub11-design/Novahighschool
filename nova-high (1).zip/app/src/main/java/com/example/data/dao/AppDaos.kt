package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Assignment
import com.example.data.model.Course
import com.example.data.model.LabReport
import com.example.data.model.StudyNote
import kotlinx.coroutines.flow.Flow

@Dao
interface CourseDao {
    @Query("SELECT * FROM courses ORDER BY period ASC")
    fun getAllCourses(): Flow<List<Course>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: Course)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCourses(courses: List<Course>)

    @Update
    suspend fun updateCourse(course: Course)

    @Query("SELECT COUNT(*) FROM courses")
    suspend fun getCourseCount(): Int
}

@Dao
interface AssignmentDao {
    @Query("SELECT * FROM assignments ORDER BY isCompleted ASC, id DESC")
    fun getAllAssignments(): Flow<List<Assignment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssignment(assignment: Assignment)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAssignments(assignments: List<Assignment>)

    @Update
    suspend fun updateAssignment(assignment: Assignment)

    @Delete
    suspend fun deleteAssignment(assignment: Assignment)

    @Query("SELECT COUNT(*) FROM assignments")
    suspend fun getAssignmentCount(): Int
}

@Dao
interface LabReportDao {
    @Query("SELECT * FROM lab_reports ORDER BY id DESC")
    fun getAllLabReports(): Flow<List<LabReport>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLabReport(report: LabReport)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllLabReports(reports: List<LabReport>)

    @Delete
    suspend fun deleteLabReport(report: LabReport)

    @Query("SELECT COUNT(*) FROM lab_reports")
    suspend fun getLabReportCount(): Int
}

@Dao
interface StudyNoteDao {
    @Query("SELECT * FROM study_notes ORDER BY timestamp DESC")
    fun getAllStudyNotes(): Flow<List<StudyNote>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudyNote(note: StudyNote)

    @Delete
    suspend fun deleteStudyNote(note: StudyNote)

    @Query("SELECT COUNT(*) FROM study_notes")
    suspend fun getStudyNoteCount(): Int
}
