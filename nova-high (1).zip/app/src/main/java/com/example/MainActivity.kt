package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AcademicsScreen
import com.example.ui.screens.ResearchCampusScreen
import com.example.ui.screens.ScienceLabScreen
import com.example.ui.screens.StemTutorScreen
import com.example.ui.screens.StudioAiScreen
import com.example.ui.theme.NovaHighTheme
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.HighSchoolViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NovaHighTheme {
                MainAppScreen()
            }
        }
    }
}

@Composable
fun MainAppScreen(
    viewModel: HighSchoolViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_nav_bar"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == AppNavTab.SCHEDULE,
                    onClick = { viewModel.selectTab(AppNavTab.SCHEDULE) },
                    icon = { Icon(Icons.Default.CalendarToday, contentDescription = "Academics") },
                    label = { Text("Schedule", fontSize = 11.sp, fontWeight = if (currentTab == AppNavTab.SCHEDULE) FontWeight.Bold else FontWeight.Normal) },
                    modifier = Modifier.testTag("tab_schedule")
                )
                NavigationBarItem(
                    selected = currentTab == AppNavTab.SCIENCE,
                    onClick = { viewModel.selectTab(AppNavTab.SCIENCE) },
                    icon = { Icon(Icons.Default.Science, contentDescription = "Science Lab") },
                    label = { Text("Science", fontSize = 11.sp, fontWeight = if (currentTab == AppNavTab.SCIENCE) FontWeight.Bold else FontWeight.Normal) },
                    modifier = Modifier.testTag("tab_science")
                )
                NavigationBarItem(
                    selected = currentTab == AppNavTab.AI_THINKING,
                    onClick = { viewModel.selectTab(AppNavTab.AI_THINKING) },
                    icon = { Icon(Icons.Default.Psychology, contentDescription = "STEM Tutor") },
                    label = { Text("Tutor", fontSize = 11.sp, fontWeight = if (currentTab == AppNavTab.AI_THINKING) FontWeight.Bold else FontWeight.Normal) },
                    modifier = Modifier.testTag("tab_tutor")
                )
                NavigationBarItem(
                    selected = currentTab == AppNavTab.RESEARCH,
                    onClick = { viewModel.selectTab(AppNavTab.RESEARCH) },
                    icon = { Icon(Icons.Default.Explore, contentDescription = "Research & Campus") },
                    label = { Text("Research", fontSize = 11.sp, fontWeight = if (currentTab == AppNavTab.RESEARCH) FontWeight.Bold else FontWeight.Normal) },
                    modifier = Modifier.testTag("tab_research")
                )
                NavigationBarItem(
                    selected = currentTab == AppNavTab.MEDIA_STUDIO,
                    onClick = { viewModel.selectTab(AppNavTab.MEDIA_STUDIO) },
                    icon = { Icon(Icons.Default.AutoFixHigh, contentDescription = "Creative Studio") },
                    label = { Text("Studio", fontSize = 11.sp, fontWeight = if (currentTab == AppNavTab.MEDIA_STUDIO) FontWeight.Bold else FontWeight.Normal) },
                    modifier = Modifier.testTag("tab_studio")
                )
            }
        }
    ) { innerPadding ->
        Crossfade(
            targetState = currentTab,
            label = "ScreenTransition",
            modifier = Modifier.padding(innerPadding)
        ) { tab ->
            when (tab) {
                AppNavTab.SCHEDULE -> AcademicsScreen(viewModel = viewModel)
                AppNavTab.SCIENCE -> ScienceLabScreen(viewModel = viewModel)
                AppNavTab.AI_THINKING -> StemTutorScreen(viewModel = viewModel)
                AppNavTab.RESEARCH -> ResearchCampusScreen(viewModel = viewModel)
                AppNavTab.MEDIA_STUDIO -> StudioAiScreen(viewModel = viewModel)
            }
        }
    }
}
