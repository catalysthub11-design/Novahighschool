package com.example.ui.viewmodel

import android.app.Application
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiClient
import com.example.data.database.AppDatabase
import com.example.data.model.Assignment
import com.example.data.model.Course
import com.example.data.model.LabReport
import com.example.data.model.StudyNote
import com.example.data.repository.HighSchoolRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

enum class AppNavTab(val title: String) {
    SCHEDULE("Academics"),
    SCIENCE("Science Lab"),
    AI_THINKING("STEM Tutor"),
    RESEARCH("Research & Campus"),
    MEDIA_STUDIO("Studio AI")
}

class HighSchoolViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: HighSchoolRepository
    private var androidTts: TextToSpeech? = null

    init {
        val db = AppDatabase.getDatabase(application)
        repository = HighSchoolRepository(db)
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }

        try {
            androidTts = TextToSpeech(application) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    androidTts?.language = Locale.US
                }
            }
        } catch (_: Exception) {}
    }

    override fun onCleared() {
        super.onCleared()
        androidTts?.stop()
        androidTts?.shutdown()
    }

    // --- Database Flows ---
    val courses: StateFlow<List<Course>> = repository.allCourses.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val assignments: StateFlow<List<Assignment>> = repository.allAssignments.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val labReports: StateFlow<List<LabReport>> = repository.allLabReports.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val studyNotes: StateFlow<List<StudyNote>> = repository.allStudyNotes.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // --- Navigation & Filter State ---
    private val _currentTab = MutableStateFlow(AppNavTab.SCHEDULE)
    val currentTab: StateFlow<AppNavTab> = _currentTab.asStateFlow()

    fun selectTab(tab: AppNavTab) {
        _currentTab.value = tab
    }

    // --- Assignment Management ---
    fun toggleAssignmentCompletion(assignment: Assignment) {
        viewModelScope.launch {
            repository.updateAssignment(assignment.copy(isCompleted = !assignment.isCompleted))
        }
    }

    fun addAssignment(courseCode: String, title: String, dueDate: String, priority: String, notes: String) {
        viewModelScope.launch {
            val newA = Assignment(
                courseCode = courseCode,
                title = title,
                dueDate = dueDate,
                priority = priority,
                isCompleted = false,
                notes = notes
            )
            repository.insertAssignment(newA)
        }
    }

    fun deleteAssignment(assignment: Assignment) {
        viewModelScope.launch {
            repository.deleteAssignment(assignment)
        }
    }

    fun addLabReport(title: String, subject: String, hypothesis: String, procedure: String, observations: String, conclusion: String) {
        viewModelScope.launch {
            val report = LabReport(
                title = title,
                subject = subject,
                date = "Oct 2026",
                hypothesis = hypothesis,
                procedure = procedure,
                observations = observations,
                conclusion = conclusion
            )
            repository.insertLabReport(report)
        }
    }

    fun deleteLabReport(report: LabReport) {
        viewModelScope.launch {
            repository.deleteLabReport(report)
        }
    }

    fun addStudyNote(title: String, subject: String, content: String) {
        viewModelScope.launch {
            repository.insertStudyNote(StudyNote(title = title, subject = subject, content = content))
        }
    }

    // --- 1. Deep Thinking STEM Solver (gemini-3.1-pro-preview + HIGH thinking) ---
    private val _thinkingInput = MutableStateFlow("Derive the maximum height and range of a projectile launched at angle theta on an incline.")
    val thinkingInput: StateFlow<String> = _thinkingInput.asStateFlow()

    private val _thinkingProcess = MutableStateFlow("")
    val thinkingProcess: StateFlow<String> = _thinkingProcess.asStateFlow()

    private val _thinkingSolution = MutableStateFlow("")
    val thinkingSolution: StateFlow<String> = _thinkingSolution.asStateFlow()

    private val _isThinkingLoading = MutableStateFlow(false)
    val isThinkingLoading: StateFlow<Boolean> = _isThinkingLoading.asStateFlow()

    fun updateThinkingInput(value: String) { _thinkingInput.value = value }

    fun runDeepThinkingSolve() {
        val query = _thinkingInput.value.trim()
        if (query.isEmpty()) return

        viewModelScope.launch {
            _isThinkingLoading.value = true
            _thinkingProcess.value = "Initiating high-thinking mode with gemini-3.1-pro-preview...\nAnalyzing physical constraints & boundary conditions..."
            val result = GeminiClient.generateDeepThinking(query)
            _thinkingProcess.value = result.first
            _thinkingSolution.value = result.second
            _isThinkingLoading.value = false
        }
    }

    // --- 2. Live Voice Conversation (gemini-3.8-live) ---
    private val _voiceHistory = MutableStateFlow<List<Pair<String, String>>>(listOf(
        Pair("model", "Hello! I am Nova, your high school STEM & study mentor. Tap Speak or type a question to begin!")
    ))
    val voiceHistory: StateFlow<List<Pair<String, String>>> = _voiceHistory.asStateFlow()

    private val _isVoiceListening = MutableStateFlow(false)
    val isVoiceListening: StateFlow<Boolean> = _isVoiceListening.asStateFlow()

    private val _isVoiceResponding = MutableStateFlow(false)
    val isVoiceResponding: StateFlow<Boolean> = _isVoiceResponding.asStateFlow()

    fun sendVoiceUtterance(text: String) {
        if (text.isBlank()) return
        val current = _voiceHistory.value.toMutableList()
        current.add(Pair("user", text))
        _voiceHistory.value = current

        viewModelScope.launch {
            _isVoiceResponding.value = true
            val reply = GeminiClient.liveVoiceConversation(text, current)
            val updated = _voiceHistory.value.toMutableList()
            updated.add(Pair("model", reply))
            _voiceHistory.value = updated
            _isVoiceResponding.value = false

            // Automatically speak the response
            speakText(reply)
        }
    }

    // --- Quick Flashcard with gemini-3.1-flash-lite ---
    private val _quickFlashResult = MutableStateFlow("• Core Mechanism: Photons excite electrons in Photosystem II (P680) -> Electron Transport Chain -> Photosystem I (P700) -> NADPH.\n• Photolysis of H₂O releases O₂.\n• ATP Synthase utilizes proton gradient across thylakoid membrane.")
    val quickFlashResult: StateFlow<String> = _quickFlashResult.asStateFlow()

    private val _isQuickFlashLoading = MutableStateFlow(false)
    val isQuickFlashLoading: StateFlow<Boolean> = _isQuickFlashLoading.asStateFlow()

    fun generateQuickFlash(topic: String) {
        if (topic.isBlank()) return
        viewModelScope.launch {
            _isQuickFlashLoading.value = true
            val res = GeminiClient.generateText("Create an AP High School level 30-second flashcard study summary with key equations and bullet points for: $topic", fastMode = true)
            _quickFlashResult.value = res
            _isQuickFlashLoading.value = false
        }
    }

    // --- 3. Google Search Grounding (gemini-3.5-flash + search) ---
    private val _searchQuery = MutableStateFlow("AP Chemistry and Physics C exam updates 2026-2027")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResult = MutableStateFlow("")
    val searchResult: StateFlow<String> = _searchResult.asStateFlow()

    private val _searchSources = MutableStateFlow<List<String>>(emptyList())
    val searchSources: StateFlow<List<String>> = _searchSources.asStateFlow()

    private val _isSearchLoading = MutableStateFlow(false)
    val isSearchLoading: StateFlow<Boolean> = _isSearchLoading.asStateFlow()

    fun updateSearchQuery(q: String) { _searchQuery.value = q }

    fun executeSearchGrounding() {
        if (_searchQuery.value.isBlank()) return
        viewModelScope.launch {
            _isSearchLoading.value = true
            val (text, sources) = GeminiClient.searchGrounding(_searchQuery.value)
            _searchResult.value = text
            _searchSources.value = sources
            _isSearchLoading.value = false
        }
    }

    // --- 4. Google Maps Grounding (gemini-3.5-flash + maps) ---
    private val _mapsQuery = MutableStateFlow("Top science museums, STEM laboratories, and public university libraries near high school")
    val mapsQuery: StateFlow<String> = _mapsQuery.asStateFlow()

    private val _mapsResult = MutableStateFlow("")
    val mapsResult: StateFlow<String> = _mapsResult.asStateFlow()

    private val _isMapsLoading = MutableStateFlow(false)
    val isMapsLoading: StateFlow<Boolean> = _isMapsLoading.asStateFlow()

    fun updateMapsQuery(q: String) { _mapsQuery.value = q }

    fun executeMapsGrounding() {
        if (_mapsQuery.value.isBlank()) return
        viewModelScope.launch {
            _isMapsLoading.value = true
            val result = GeminiClient.mapsGrounding(_mapsQuery.value)
            _mapsResult.value = result
            _isMapsLoading.value = false
        }
    }

    // --- 5. High Quality Diagram / Image Generator (gemini-3-pro-image-preview) ---
    private val _imagePrompt = MutableStateFlow("Cross-section diagram of an animal cell showing mitochondria, nucleus, and endoplasmic reticulum with labeled scientific calligraphy")
    val imagePrompt: StateFlow<String> = _imagePrompt.asStateFlow()

    private val _selectedImageSize = MutableStateFlow("1K") // 1K, 2K, 4K
    val selectedImageSize: StateFlow<String> = _selectedImageSize.asStateFlow()

    private val _generatedImageBase64 = MutableStateFlow<String?>(null)
    val generatedImageBase64: StateFlow<String?> = _generatedImageBase64.asStateFlow()

    private val _imageGenerationStatus = MutableStateFlow("")
    val imageGenerationStatus: StateFlow<String> = _imageGenerationStatus.asStateFlow()

    private val _isImageLoading = MutableStateFlow(false)
    val isImageLoading: StateFlow<Boolean> = _isImageLoading.asStateFlow()

    fun updateImagePrompt(p: String) { _imagePrompt.value = p }
    fun selectImageSize(size: String) { _selectedImageSize.value = size }

    fun generateDiagramImage() {
        if (_imagePrompt.value.isBlank()) return
        viewModelScope.launch {
            _isImageLoading.value = true
            _imageGenerationStatus.value = "Generating high-resolution diagram (${_selectedImageSize.value}) using gemini-3-pro-image-preview..."
            val (base64, msg) = GeminiClient.generateHighQualityImage(_imagePrompt.value, _selectedImageSize.value)
            _generatedImageBase64.value = base64
            _imageGenerationStatus.value = msg
            _isImageLoading.value = false
        }
    }

    // --- 6. Text to Speech (TTS) (gemini-3.8-flash-tts) ---
    private val _ttsStatus = MutableStateFlow("")
    val ttsStatus: StateFlow<String> = _ttsStatus.asStateFlow()

    private val _isTtsPlaying = MutableStateFlow(false)
    val isTtsPlaying: StateFlow<Boolean> = _isTtsPlaying.asStateFlow()

    fun speakText(text: String) {
        viewModelScope.launch {
            _isTtsPlaying.value = true
            _ttsStatus.value = "Generating speech via gemini-3.8-flash-tts..."
            val audioBytes = GeminiClient.generateTTS(text)
            if (audioBytes != null && audioBytes.isNotEmpty()) {
                _ttsStatus.value = "Playing audio stream..."
                playPcmOrAudio(audioBytes)
            } else {
                _ttsStatus.value = "Playing via Android Speech synthesizer..."
                androidTts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "TTS_ID")
            }
            _isTtsPlaying.value = false
        }
    }

    private fun playPcmOrAudio(bytes: ByteArray) {
        try {
            val sampleRate = 24000
            val channelConfig = AudioFormat.CHANNEL_OUT_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val bufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat).coerceAtLeast(bytes.size)
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(audioFormat)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelConfig)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .build()

            audioTrack.play()
            audioTrack.write(bytes, 0, bytes.size)
            audioTrack.stop()
            audioTrack.release()
        } catch (_: Exception) {}
    }

    // --- 7. Music Generation (lyria-3-clip-preview & lyria-3-pro-preview) ---
    private val _musicPrompt = MutableStateFlow("Relaxing chill-hop study beats with soft piano and ambient rain for high school homework")
    val musicPrompt: StateFlow<String> = _musicPrompt.asStateFlow()

    private val _isFullLengthMusic = MutableStateFlow(false) // false = 30s clip, true = full track
    val isFullLengthMusic: StateFlow<Boolean> = _isFullLengthMusic.asStateFlow()

    private val _musicStatus = MutableStateFlow("")
    val musicStatus: StateFlow<String> = _musicStatus.asStateFlow()

    private val _isMusicGenerating = MutableStateFlow(false)
    val isMusicGenerating: StateFlow<Boolean> = _isMusicGenerating.asStateFlow()

    fun updateMusicPrompt(p: String) { _musicPrompt.value = p }
    fun setFullLengthMusic(full: Boolean) { _isFullLengthMusic.value = full }

    fun generateStudyMusic() {
        if (_musicPrompt.value.isBlank()) return
        viewModelScope.launch {
            _isMusicGenerating.value = true
            val modelName = if (_isFullLengthMusic.value) "lyria-3-pro-preview" else "lyria-3-clip-preview"
            _musicStatus.value = "Synthesizing audio track using $modelName..."
            val (audioBytes, msg) = GeminiClient.generateMusic(_musicPrompt.value, _isFullLengthMusic.value)
            _musicStatus.value = msg
            if (audioBytes != null) {
                playPcmOrAudio(audioBytes)
            }
            _isMusicGenerating.value = false
        }
    }

    // --- 8. Veo Video Animation (veo-3.1-fast-generate-preview) ---
    private val _videoPrompt = MutableStateFlow("Animate chemical reaction: hydrochloric acid dropping into sodium hydroxide solution with thermal convection and color change from clear to pink")
    val videoPrompt: StateFlow<String> = _videoPrompt.asStateFlow()

    private val _videoAspectRatio = MutableStateFlow("16:9") // 16:9 or 9:16
    val videoAspectRatio: StateFlow<String> = _videoAspectRatio.asStateFlow()

    private val _videoStatus = MutableStateFlow("")
    val videoStatus: StateFlow<String> = _videoStatus.asStateFlow()

    private val _isVideoGenerating = MutableStateFlow(false)
    val isVideoGenerating: StateFlow<Boolean> = _isVideoGenerating.asStateFlow()

    fun updateVideoPrompt(p: String) { _videoPrompt.value = p }
    fun setVideoAspectRatio(ratio: String) { _videoAspectRatio.value = ratio }

    fun generateVeoVideo() {
        if (_videoPrompt.value.isBlank()) return
        viewModelScope.launch {
            _isVideoGenerating.value = true
            _videoStatus.value = "Dispatching Veo fast video generation (${_videoAspectRatio.value})..."
            val (_, msg) = GeminiClient.generateVideo(_videoPrompt.value, _videoAspectRatio.value)
            _videoStatus.value = msg
            _isVideoGenerating.value = false
        }
    }
}
