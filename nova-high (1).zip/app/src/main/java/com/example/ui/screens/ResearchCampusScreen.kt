package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.HighSchoolViewModel

enum class ResearchTab(val title: String) {
    SEARCH_GROUNDING("Academic Search"),
    MAPS_GROUNDING("Campus & Field Trips")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResearchCampusScreen(
    viewModel: HighSchoolViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(ResearchTab.SEARCH_GROUNDING) }

    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResult by viewModel.searchResult.collectAsState()
    val searchSources by viewModel.searchSources.collectAsState()
    val isSearchLoading by viewModel.isSearchLoading.collectAsState()

    val mapsQuery by viewModel.mapsQuery.collectAsState()
    val mapsResult by viewModel.mapsResult.collectAsState()
    val isMapsLoading by viewModel.isMapsLoading.collectAsState()

    val uriHandler = LocalUriHandler.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Explore,
                                    contentDescription = "Research & Campus",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Research & Grounded Intel", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Google Search & Maps Grounding (gemini-3.5-flash)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab.ordinal,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                ResearchTab.values().forEach { tab ->
                    Tab(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        text = {
                            Text(
                                tab.title,
                                fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedTab) {
                    ResearchTab.SEARCH_GROUNDING -> {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Google Search Grounding", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Queries gemini-3.5-flash armed with real-time googleSearch tool. Verifies AP testing deadlines, college admissions policies, scholarships, and breaking scientific discoveries.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }

                        // Presets
                        item {
                            Text("Academic Research Queries:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SuggestionChip(
                                    onClick = { viewModel.updateSearchQuery("AP Exam dates and College Board registration schedule 2026-2027") },
                                    label = { Text("AP Dates", fontSize = 11.sp) }
                                )
                                SuggestionChip(
                                    onClick = { viewModel.updateSearchQuery("Regeneron ISEF high school science fair guidelines and deadlines") },
                                    label = { Text("ISEF Science Fair", fontSize = 11.sp) }
                                )
                                SuggestionChip(
                                    onClick = { viewModel.updateSearchQuery("National Merit Semifinalist cutoff scores for 2026") },
                                    label = { Text("National Merit", fontSize = 11.sp) }
                                )
                            }
                        }

                        // Input Box
                        item {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { viewModel.updateSearchQuery(it) },
                                label = { Text("Academic Search Query") },
                                modifier = Modifier.fillMaxWidth().testTag("search_query_field")
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.executeSearchGrounding() },
                                enabled = !isSearchLoading && searchQuery.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().testTag("run_search_btn")
                            ) {
                                if (isSearchLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Grounding with Google Search...")
                                } else {
                                    Icon(Icons.Default.ManageSearch, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Verify with Google Search")
                                }
                            }
                        }

                        // Search Results
                        if (searchResult.isNotBlank()) {
                            item {
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Grounded Intelligence", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                                            FilledTonalIconButton(
                                                onClick = { viewModel.speakText(searchResult) }
                                            ) {
                                                Icon(Icons.Default.VolumeUp, contentDescription = "TTS Readout")
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(searchResult, fontSize = 14.sp, lineHeight = 20.sp)

                                        if (searchSources.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(12.dp))
                                            HorizontalDivider()
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text("Verified Sources & Web Citations:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            searchSources.forEach { url ->
                                                Text(
                                                    text = "🔗 $url",
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier
                                                        .padding(vertical = 2.dp)
                                                        .clickable {
                                                            try { uriHandler.openUri(url) } catch (_: Exception) {}
                                                        }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    ResearchTab.MAPS_GROUNDING -> {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Google Maps Grounding", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Powered by gemini-3.5-flash with googleMaps tool. Discover nearby science museums, university laboratories, STEM centers, public libraries, and field trip destinations.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }

                        // Presets
                        item {
                            Text("Quick Campus & Science Queries:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SuggestionChip(
                                    onClick = { viewModel.updateMapsQuery("Best public STEM libraries and quiet study spots near high school") },
                                    label = { Text("Study Libraries", fontSize = 11.sp) }
                                )
                                SuggestionChip(
                                    onClick = { viewModel.updateMapsQuery("Science centers, planetariums, and robotics makerspaces nearby") },
                                    label = { Text("Science Centers", fontSize = 11.sp) }
                                )
                                SuggestionChip(
                                    onClick = { viewModel.updateMapsQuery("Top universities and college admissions centers in the region") },
                                    label = { Text("College Tours", fontSize = 11.sp) }
                                )
                            }
                        }

                        // Input Box
                        item {
                            OutlinedTextField(
                                value = mapsQuery,
                                onValueChange = { viewModel.updateMapsQuery(it) },
                                label = { Text("Location & Destination Query") },
                                modifier = Modifier.fillMaxWidth().testTag("maps_query_field")
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.executeMapsGrounding() },
                                enabled = !isMapsLoading && mapsQuery.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().testTag("run_maps_btn")
                            ) {
                                if (isMapsLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Grounding with Google Maps...")
                                } else {
                                    Icon(Icons.Default.Map, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Locate via Google Maps")
                                }
                            }
                        }

                        // Maps Results
                        if (mapsResult.isNotBlank()) {
                            item {
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("Maps Recommendations & Details", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(mapsResult, fontSize = 14.sp, lineHeight = 20.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(60.dp)) }
            }
        }
    }
}
