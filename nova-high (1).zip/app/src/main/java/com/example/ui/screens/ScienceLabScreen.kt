package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.pow
import com.example.data.model.LabReport
import com.example.science.ScienceEngine
import com.example.ui.viewmodel.HighSchoolViewModel

enum class ScienceDiscipline(val label: String) {
    CHEMISTRY("Chemistry"),
    PHYSICS("Physics"),
    BIOLOGY("Biology"),
    LAB_REPORTS("Lab Notebook")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScienceLabScreen(
    viewModel: HighSchoolViewModel,
    modifier: Modifier = Modifier
) {
    var selectedDiscipline by remember { mutableStateOf(ScienceDiscipline.CHEMISTRY) }
    val labReports by viewModel.labReports.collectAsState()
    var showNewReportDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Biotech,
                                    contentDescription = "Science Icon",
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("High School Science Hub", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Interactive STEM Solvers & Experiments", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Science Discipline Selector Chips
            ScrollableTabRow(
                selectedTabIndex = selectedDiscipline.ordinal,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                ScienceDiscipline.values().forEach { discipline ->
                    Tab(
                        selected = selectedDiscipline == discipline,
                        onClick = { selectedDiscipline = discipline },
                        text = {
                            Text(
                                discipline.label,
                                fontWeight = if (selectedDiscipline == discipline) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedDiscipline) {
                    ScienceDiscipline.CHEMISTRY -> {
                        item { PeriodicTableExplorer() }
                        item { MolarMassCalculatorSection() }
                        item { PhSimulatorSection() }
                    }
                    ScienceDiscipline.PHYSICS -> {
                        item { KinematicsSolverSection() }
                        item { OhmsLawSection() }
                    }
                    ScienceDiscipline.BIOLOGY -> {
                        item { PunnettSquareSection() }
                        item { CentralDogmaSection() }
                    }
                    ScienceDiscipline.LAB_REPORTS -> {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Experimental Lab Reports", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Button(
                                    onClick = { showNewReportDialog = true },
                                    modifier = Modifier.testTag("add_lab_report_btn")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("New Report")
                                }
                            }
                        }
                        items(labReports) { report ->
                            LabReportCard(report = report, onDelete = { viewModel.deleteLabReport(report) })
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(60.dp)) }
            }
        }
    }

    if (showNewReportDialog) {
        var title by remember { mutableStateOf("") }
        var subject by remember { mutableStateOf("Chemistry") }
        var hypothesis by remember { mutableStateOf("") }
        var procedure by remember { mutableStateOf("") }
        var observations by remember { mutableStateOf("") }
        var conclusion by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showNewReportDialog = false },
            title = { Text("New Science Lab Report") },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Experiment Title") },
                        modifier = Modifier.fillMaxWidth().testTag("lab_report_title_input")
                    )
                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Subject (e.g. Physics, Chemistry)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = hypothesis,
                        onValueChange = { hypothesis = it },
                        label = { Text("Hypothesis") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = procedure,
                        onValueChange = { procedure = it },
                        label = { Text("Procedure Summary") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = observations,
                        onValueChange = { observations = it },
                        label = { Text("Observations & Data") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = conclusion,
                        onValueChange = { conclusion = it },
                        label = { Text("Scientific Conclusion") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            viewModel.addLabReport(title, subject, hypothesis, procedure, observations, conclusion)
                            showNewReportDialog = false
                        }
                    },
                    modifier = Modifier.testTag("confirm_lab_report_btn")
                ) {
                    Text("Save Report")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewReportDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// --- Chemistry: Periodic Table Explorer ---
@Composable
fun PeriodicTableExplorer() {
    var selectedElement by remember { mutableStateOf(ScienceEngine.elements[5]) } // Carbon

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Interactive Periodic Table", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Tap element to inspect", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(10.dp))

            // Horizontal scrolling row of elements
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(ScienceEngine.elements) { el ->
                    val isSelected = el.symbol == selectedElement.symbol
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier
                            .size(62.dp)
                            .clickable { selectedElement = el }
                            .testTag("element_${el.symbol}")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                "${el.atomicNumber}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                el.symbol,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "%.1f".format(el.atomicMass),
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Details card for selected element
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(54.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("${selectedElement.atomicNumber}", fontSize = 10.sp, color = Color.White)
                            Text(selectedElement.symbol, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("${selectedElement.name} (${selectedElement.category})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Standard Atomic Mass: ${selectedElement.atomicMass} u", fontSize = 12.sp)
                        Text("Electron Configuration: ${selectedElement.electronConfig}", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

// --- Chemistry: Molar Mass Calculator ---
@Composable
fun MolarMassCalculatorSection() {
    var formula by remember { mutableStateOf("H2SO4") }
    val (molarMass, breakdown) = remember(formula) {
        ScienceEngine.calculateMolarMass(formula)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Molar Mass & Formula Calculator", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Enter chemical formula (e.g. H2SO4, C6H12O6, NaCl)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = formula,
                onValueChange = { formula = it },
                label = { Text("Formula") },
                modifier = Modifier.fillMaxWidth().testTag("formula_input")
            )
            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        "Total Molar Mass: %.3f g/mol".format(molarMass),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    val breakdownStr = breakdown.entries.joinToString(" + ") { (sym, mass) ->
                        "$sym: %.2f g/mol".format(mass)
                    }
                    Text("Breakdown: $breakdownStr", fontSize = 12.sp)
                }
            }
        }
    }
}

// --- Chemistry: pH & Acid-Base Simulator ---
@Composable
fun PhSimulatorSection() {
    var phValue by remember { mutableStateOf(7.0f) }
    val hConc = 10.0.pow(-phValue.toDouble())
    val (_, poh, desc) = ScienceEngine.calculatePH(hConc)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Acid-Base pH & Hydronium Simulator", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Adjust pH scale slider from 0 (Strong Acid) to 14 (Strong Base)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("pH: %.1f".format(phValue), fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Text("pOH: %.1f".format(poh), fontSize = 14.sp)
                Text(
                    desc,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = if (phValue < 7) Color(0xFFDC2626) else if (phValue > 7) Color(0xFF2563EB) else Color(0xFF059669)
                )
            }

            Slider(
                value = phValue,
                onValueChange = { phValue = it },
                valueRange = 0f..14f,
                steps = 27,
                modifier = Modifier.testTag("ph_slider")
            )

            Text(
                "[H⁺] = %.2e M | [OH⁻] = %.2e M".format(hConc, 10.0.pow(-poh)),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// --- Physics: Kinematics Solver ---
@Composable
fun KinematicsSolverSection() {
    var uText by remember { mutableStateOf("0.0") }
    var aText by remember { mutableStateOf("9.8") }
    var tText by remember { mutableStateOf("3.0") }

    val u = uText.toDoubleOrNull() ?: 0.0
    val a = aText.toDoubleOrNull() ?: 9.8
    val t = tText.toDoubleOrNull() ?: 3.0

    val result = remember(u, a, t) {
        ScienceEngine.solveKinematics(u, a, t)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Kinematics 1D & 2D Motion Solver", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Solves v = u + at, d = ut + ½at², and kinetic work", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = uText,
                    onValueChange = { uText = it },
                    label = { Text("u (m/s)") },
                    modifier = Modifier.weight(1f).testTag("kinematics_u_input")
                )
                OutlinedTextField(
                    value = aText,
                    onValueChange = { aText = it },
                    label = { Text("a (m/s²)") },
                    modifier = Modifier.weight(1f).testTag("kinematics_a_input")
                )
                OutlinedTextField(
                    value = tText,
                    onValueChange = { tText = it },
                    label = { Text("t (s)") },
                    modifier = Modifier.weight(1f).testTag("kinematics_t_input")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Final Velocity (v): %.2f m/s".format(result.finalVelocity), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Total Displacement (d): %.2f meters".format(result.displacement), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Average Velocity: %.2f m/s".format(result.avgVelocity), fontSize = 12.sp)
                    Text("Specific Kinetic Energy: %.2f J/kg".format(result.kineticEnergyPerKg), fontSize = 12.sp)
                }
            }
        }
    }
}

// --- Physics: Ohm's Law Section ---
@Composable
fun OhmsLawSection() {
    var vText by remember { mutableStateOf("12.0") }
    var rText by remember { mutableStateOf("4.0") }

    val v = vText.toDoubleOrNull() ?: 12.0
    val r = rText.toDoubleOrNull() ?: 4.0
    val circuit = remember(v, r) {
        ScienceEngine.solveOhmsLaw(voltage = v, current = null, resistance = r)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("DC Circuit Ohm's Law & Power", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("V = I × R, Power P = V × I = I²R", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = vText,
                    onValueChange = { vText = it },
                    label = { Text("Voltage (V)") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = rText,
                    onValueChange = { rText = it },
                    label = { Text("Resistance (Ω)") },
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.tertiaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Current (I): %.2f Amperes (A)".format(circuit.current), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Power Dissipation (P): %.2f Watts (W)".format(circuit.powerWatts), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

// --- Biology: Punnett Square Genetics ---
@Composable
fun PunnettSquareSection() {
    var parent1 by remember { mutableStateOf("Bb") }
    var parent2 by remember { mutableStateOf("Bb") }

    val punnett = remember(parent1, parent2) {
        ScienceEngine.calculatePunnettSquare(parent1, parent2)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Punnett Square Mendelian Genetics", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Monohybrid cross with dominant & recessive alleles", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = parent1,
                    onValueChange = { parent1 = it },
                    label = { Text("Parent 1 (e.g. Bb)") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = parent2,
                    onValueChange = { parent2 = it },
                    label = { Text("Parent 2 (e.g. Bb)") },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2x2 Visual Grid
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(punnett.grid[0][0], fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    }
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(punnett.grid[0][1], fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(punnett.grid[1][0], fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    }
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(punnett.grid[1][1], fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("Genotypic Ratio: ${punnett.genotypicRatio}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("Phenotypic Ratio: ${punnett.phenotypicRatio}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

// --- Biology: Central Dogma DNA to Amino Acid ---
@Composable
fun CentralDogmaSection() {
    var dnaInput by remember { mutableStateOf("TACGGCTTTACT") }
    val (mrna, aminoAcids) = remember(dnaInput) {
        ScienceEngine.transcribeAndTranslateDna(dnaInput)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Central Dogma: DNA Transcription & Translation", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Enter template DNA strand (A, T, C, G)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = dnaInput,
                onValueChange = { dnaInput = it },
                label = { Text("DNA Strand") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("mRNA Transcript: $mrna", fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Peptide Chain: ${aminoAcids.joinToString(" -> ")}", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

// --- Lab Report Card ---
@Composable
fun LabReportCard(
    report: LabReport,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.tertiaryContainer
                ) {
                    Text(
                        report.subject,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(report.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("Date: ${report.date}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))

            Text("Hypothesis:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text(report.hypothesis, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))

            Text("Conclusion:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text(report.conclusion, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
