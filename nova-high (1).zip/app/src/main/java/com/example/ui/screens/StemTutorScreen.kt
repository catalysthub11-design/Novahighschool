package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.HighSchoolViewModel

enum class TutorMode(val title: String) {
    DEEP_THINKING("High Thinking STEM"),
    VOICE_SESSION("Live Voice Tutor"),
    QUICK_FLASH("Fast AI Study")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StemTutorScreen(
    viewModel: HighSchoolViewModel,
    modifier: Modifier = Modifier
) {
    var selectedMode by remember { mutableStateOf(TutorMode.DEEP_THINKING) }

    val thinkingInput by viewModel.thinkingInput.collectAsState()
    val thinkingProcess by viewModel.thinkingProcess.collectAsState()
    val thinkingSolution by viewModel.thinkingSolution.collectAsState()
    val isThinkingLoading by viewModel.isThinkingLoading.collectAsState()

    val voiceHistory by viewModel.voiceHistory.collectAsState()
    val isVoiceResponding by viewModel.isVoiceResponding.collectAsState()

    var showThinkingProcessDetails by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Psychology,
                                    contentDescription = "STEM Tutor",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Nova STEM Intelligence", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("High Thinking • Live Voice • Fast Flashcards", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Mode Tabs
            TabRow(
                selectedTabIndex = selectedMode.ordinal,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                TutorMode.values().forEach { mode ->
                    Tab(
                        selected = selectedMode == mode,
                        onClick = { selectedMode = mode },
                        text = {
                            Text(
                                mode.title,
                                fontWeight = if (selectedMode == mode) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedMode) {
                    TutorMode.DEEP_THINKING -> {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("High Thinking Engine", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Powered by gemini-3.1-pro-preview with thinkingLevel = HIGH. Unravels multi-step derivations, AP Physics, Calculus, and Organic Chemistry with full internal reasoning visibility.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }

                        // Presets
                        item {
                            Text("Sample High School Challenge Prompts:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                SuggestionChip(
                                    onClick = {
                                        viewModel.updateThinkingInput("Derive the maximum height and range of a projectile launched at angle theta on an incline.")
                                    },
                                    label = { Text("Inclined Projectile", fontSize = 11.sp) }
                                )
                                SuggestionChip(
                                    onClick = {
                                        viewModel.updateThinkingInput("Calculate pH of buffer solution with 0.1M CH3COOH (Ka=1.8e-5) and 0.1M CH3COONa using Henderson-Hasselbalch.")
                                    },
                                    label = { Text("Buffer pH", fontSize = 11.sp) }
                                )
                                SuggestionChip(
                                    onClick = {
                                        viewModel.updateThinkingInput("Solve AP Calculus BC volume of solid with base y = sqrt(x) and cross sections perpendicular to x-axis are squares.")
                                    },
                                    label = { Text("Calc BC Solid", fontSize = 11.sp) }
                                )
                            }
                        }

                        // Input Box
                        item {
                            OutlinedTextField(
                                value = thinkingInput,
                                onValueChange = { viewModel.updateThinkingInput(it) },
                                label = { Text("Enter Complex STEM Problem") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("thinking_input_field"),
                                minLines = 3
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.runDeepThinkingSolve() },
                                enabled = !isThinkingLoading && thinkingInput.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("run_thinking_btn")
                            ) {
                                if (isThinkingLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Deep Thinking in Progress...")
                                } else {
                                    Icon(Icons.Default.Bolt, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Solve with High Thinking (gemini-3.1-pro-preview)")
                                }
                            }
                        }

                        // Thinking Process Inspection Box
                        if (thinkingProcess.isNotBlank()) {
                            item {
                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { showThinkingProcessDetails = !showThinkingProcessDetails },
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Psychology, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("Thinking Process (thinkingLevel: HIGH)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            }
                                            Icon(
                                                if (showThinkingProcessDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                contentDescription = "Toggle"
                                            )
                                        }

                                        AnimatedVisibility(visible = showThinkingProcessDetails) {
                                            Column(modifier = Modifier.padding(top = 8.dp)) {
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = MaterialTheme.colorScheme.surface,
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text(
                                                        text = thinkingProcess,
                                                        fontFamily = FontFamily.Monospace,
                                                        fontSize = 11.sp,
                                                        modifier = Modifier.padding(10.dp),
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Solution Card
                        if (thinkingSolution.isNotBlank()) {
                            item {
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Final Mathematical Solution", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                                            FilledTonalIconButton(
                                                onClick = { viewModel.speakText(thinkingSolution) }
                                            ) {
                                                Icon(Icons.Default.VolumeUp, contentDescription = "Read aloud via TTS")
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(thinkingSolution, fontSize = 14.sp, lineHeight = 20.sp)
                                    }
                                }
                            }
                        }
                    }

                    TutorMode.VOICE_SESSION -> {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("Nova Voice Study Session", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text("Real-time voice tutor powered by gemini-3.8-live (Live API)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                    Spacer(modifier = Modifier.height(14.dp))

                                    Surface(
                                        shape = CircleShape,
                                        color = if (isVoiceResponding) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(72.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                if (isVoiceResponding) Icons.Default.Hearing else Icons.Default.Mic,
                                                contentDescription = "Voice Indicator",
                                                tint = Color.White,
                                                modifier = Modifier.size(36.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        if (isVoiceResponding) "Nova is speaking..." else "Tap or ask any study question",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        // Conversation turns
                        items(voiceHistory) { turn ->
                            val isModel = turn.first == "model"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (isModel) Arrangement.Start else Arrangement.End
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isModel) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.widthIn(max = 300.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            if (isModel) "Nova Tutor (gemini-3.8-live)" else "You",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(turn.second, fontSize = 13.sp)
                                    }
                                }
                            }
                        }

                        // Utterance input
                        item {
                            var utteranceText by remember { mutableStateOf("") }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = utteranceText,
                                    onValueChange = { utteranceText = it },
                                    placeholder = { Text("Ask voice tutor a question...") },
                                    modifier = Modifier.weight(1f).testTag("voice_input_box")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                IconButton(
                                    onClick = {
                                        if (utteranceText.isNotBlank()) {
                                            viewModel.sendVoiceUtterance(utteranceText)
                                            utteranceText = ""
                                        }
                                    },
                                    modifier = Modifier.testTag("send_voice_btn")
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = "Send")
                                }
                            }
                        }
                    }

                    TutorMode.QUICK_FLASH -> {
                        item {
                            var topic by remember { mutableStateOf("Photosynthesis Light Reactions") }
                            val flashResult by viewModel.quickFlashResult.collectAsState()
                            val isFastLoading by viewModel.isQuickFlashLoading.collectAsState()

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Fast Study Generator (gemini-3.1-flash-lite)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text("High-velocity model for instant flashcards and mnemonics.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(modifier = Modifier.height(10.dp))

                                    OutlinedTextField(
                                        value = topic,
                                        onValueChange = { topic = it },
                                        label = { Text("Study Topic / Concept") },
                                        modifier = Modifier.fillMaxWidth().testTag("flash_topic_input")
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = { viewModel.generateQuickFlash(topic) },
                                        enabled = !isFastLoading && topic.isNotBlank(),
                                        modifier = Modifier.fillMaxWidth().testTag("generate_flash_btn")
                                    ) {
                                        if (isFastLoading) {
                                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.onPrimary)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Generating Flashcard...")
                                        } else {
                                            Text("Generate 30-Second Flash Card")
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("Flashcard: $topic", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                FilledTonalIconButton(
                                                    onClick = { viewModel.speakText(flashResult) }
                                                ) {
                                                    Icon(Icons.Default.VolumeUp, contentDescription = "TTS")
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(flashResult, fontSize = 13.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(60.dp)) }
            }
        }
    }
}
