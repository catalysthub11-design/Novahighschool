package com.example.ui.screens

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.HighSchoolViewModel

enum class StudioCategory(val title: String) {
    DIAGRAM_GENERATOR("Diagrams (1K/2K/4K)"),
    STUDY_MUSIC("Lyria Music"),
    TEXT_TO_SPEECH("Gemini TTS"),
    VEO_VIDEO("Veo Video")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioAiScreen(
    viewModel: HighSchoolViewModel,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf(StudioCategory.DIAGRAM_GENERATOR) }

    // Diagram states
    val imagePrompt by viewModel.imagePrompt.collectAsState()
    val selectedImageSize by viewModel.selectedImageSize.collectAsState()
    val generatedImageBase64 by viewModel.generatedImageBase64.collectAsState()
    val imageStatus by viewModel.imageGenerationStatus.collectAsState()
    val isImageLoading by viewModel.isImageLoading.collectAsState()

    // Music states
    val musicPrompt by viewModel.musicPrompt.collectAsState()
    val isFullLengthMusic by viewModel.isFullLengthMusic.collectAsState()
    val musicStatus by viewModel.musicStatus.collectAsState()
    val isMusicGenerating by viewModel.isMusicGenerating.collectAsState()

    // TTS states
    var ttsInputText by remember { mutableStateOf("Mendel's Law of Segregation states that allele pairs separate during gamete formation, and randomly unite at fertilization.") }
    val isTtsPlaying by viewModel.isTtsPlaying.collectAsState()
    val ttsStatus by viewModel.ttsStatus.collectAsState()

    // Video states
    val videoPrompt by viewModel.videoPrompt.collectAsState()
    val videoAspectRatio by viewModel.videoAspectRatio.collectAsState()
    val videoStatus by viewModel.videoStatus.collectAsState()
    val isVideoGenerating by viewModel.isVideoGenerating.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.Palette,
                                    contentDescription = "Studio",
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Nova Creative Studio", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Lyria Music • Gemini TTS • 4K Diagrams • Veo", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedCategory.ordinal,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                StudioCategory.values().forEach { cat ->
                    Tab(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        text = {
                            Text(
                                cat.title,
                                fontWeight = if (selectedCategory == cat) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedCategory) {
                    StudioCategory.DIAGRAM_GENERATOR -> {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Image, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("High-Quality Science Diagrams", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Model: gemini-3-pro-image-preview. Generates detailed educational charts, biology anatomies, and physics setups with 1K, 2K, and 4K resolution options.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }

                        item {
                            Text("Resolution Affordance:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("1K", "2K", "4K").forEach { size ->
                                    FilterChip(
                                        selected = selectedImageSize == size,
                                        onClick = { viewModel.selectImageSize(size) },
                                        label = { Text("$size Resolution") },
                                        modifier = Modifier.testTag("size_chip_$size")
                                    )
                                }
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = imagePrompt,
                                onValueChange = { viewModel.updateImagePrompt(it) },
                                label = { Text("Diagram Prompt") },
                                modifier = Modifier.fillMaxWidth().testTag("image_prompt_input"),
                                minLines = 2
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.generateDiagramImage() },
                                enabled = !isImageLoading && imagePrompt.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().testTag("generate_image_btn")
                            ) {
                                if (isImageLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Rendering in $selectedImageSize...")
                                } else {
                                    Icon(Icons.Default.AutoFixHigh, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Generate Diagram ($selectedImageSize)")
                                }
                            }
                        }

                        if (imageStatus.isNotBlank()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = imageStatus,
                                        modifier = Modifier.padding(12.dp),
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }

                        if (generatedImageBase64 != null) {
                            item {
                                val bitmap = remember(generatedImageBase64) {
                                    try {
                                        val decoded = Base64.decode(generatedImageBase64, Base64.DEFAULT)
                                        BitmapFactory.decodeByteArray(decoded, 0, decoded.size)
                                    } catch (_: Exception) { null }
                                }
                                if (bitmap != null) {
                                    Card(
                                        shape = RoundedCornerShape(16.dp),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Image(
                                            bitmap = bitmap.asImageBitmap(),
                                            contentDescription = "Generated Diagram",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .aspectRatio(1f)
                                                .clip(RoundedCornerShape(16.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                }
                            }
                        }
                    }

                    StudioCategory.STUDY_MUSIC -> {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Lyria Study Beats & Ambient Audio", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Generates focus music and memorization mnemonics using lyria-3-clip-preview (up to 30s clips) or lyria-3-pro-preview (full-length tracks).",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }

                        item {
                            Text("Track Length Model:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = !isFullLengthMusic,
                                    onClick = { viewModel.setFullLengthMusic(false) },
                                    label = { Text("Short Clip (lyria-3-clip-preview ≤30s)") },
                                    modifier = Modifier.testTag("clip_music_chip")
                                )
                                FilterChip(
                                    selected = isFullLengthMusic,
                                    onClick = { viewModel.setFullLengthMusic(true) },
                                    label = { Text("Full Track (lyria-3-pro-preview)") },
                                    modifier = Modifier.testTag("pro_music_chip")
                                )
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = musicPrompt,
                                onValueChange = { viewModel.updateMusicPrompt(it) },
                                label = { Text("Study Music Prompt") },
                                modifier = Modifier.fillMaxWidth().testTag("music_prompt_input"),
                                minLines = 2
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.generateStudyMusic() },
                                enabled = !isMusicGenerating && musicPrompt.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().testTag("generate_music_btn")
                            ) {
                                if (isMusicGenerating) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Synthesizing Study Beats...")
                                } else {
                                    Icon(Icons.Default.Headphones, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Generate Study Track")
                                }
                            }
                        }

                        if (musicStatus.isNotBlank()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text("Audio Status:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(musicStatus, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }

                    StudioCategory.TEXT_TO_SPEECH -> {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("High-Fidelity Text to Speech (TTS)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Model: gemini-3.8-flash-tts. Reads out scientific theories, textbook excerpts, and study flashcards in crystal clear natural voice.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                }
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = ttsInputText,
                                onValueChange = { ttsInputText = it },
                                label = { Text("Text to Read Aloud") },
                                modifier = Modifier.fillMaxWidth().testTag("tts_text_field"),
                                minLines = 3
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.speakText(ttsInputText) },
                                enabled = !isTtsPlaying && ttsInputText.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().testTag("speak_tts_btn")
                            ) {
                                if (isTtsPlaying) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Synthesizing Speech...")
                                } else {
                                    Icon(Icons.Default.VolumeUp, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Read with gemini-3.8-flash-tts")
                                }
                            }
                        }

                        if (ttsStatus.isNotBlank()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(ttsStatus, modifier = Modifier.padding(12.dp), fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    StudioCategory.VEO_VIDEO -> {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Movie, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Veo Video Generations", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Model: veo-3.1-fast-generate-preview. Animates laboratory setups, physical phenomena, or science fair presentations into dynamic videos with 16:9 or 9:16 aspect ratio.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }

                        item {
                            Text("Aspect Ratio:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = videoAspectRatio == "16:9",
                                    onClick = { viewModel.setVideoAspectRatio("16:9") },
                                    label = { Text("16:9 (Landscape)") },
                                    modifier = Modifier.testTag("aspect_16_9_chip")
                                )
                                FilterChip(
                                    selected = videoAspectRatio == "9:16",
                                    onClick = { viewModel.setVideoAspectRatio("9:16") },
                                    label = { Text("9:16 (Portrait / Reel)") },
                                    modifier = Modifier.testTag("aspect_9_16_chip")
                                )
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = videoPrompt,
                                onValueChange = { viewModel.updateVideoPrompt(it) },
                                label = { Text("Animation Description") },
                                modifier = Modifier.fillMaxWidth().testTag("video_prompt_input"),
                                minLines = 2
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { viewModel.generateVeoVideo() },
                                enabled = !isVideoGenerating && videoPrompt.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().testTag("generate_video_btn")
                            ) {
                                if (isVideoGenerating) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Generating Video...")
                                } else {
                                    Icon(Icons.Default.Videocam, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Animate Video with Veo ($videoAspectRatio)")
                                }
                            }
                        }

                        if (videoStatus.isNotBlank()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text("Veo Generation Task:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(videoStatus, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(60.dp)) }
            }
        }
    }
}
