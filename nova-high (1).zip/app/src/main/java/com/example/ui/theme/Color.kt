package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AcademyBlue80 = Color(0xFF93C5FD)
val AcademyAmber80 = Color(0xFFFDE68A)
val AcademyEmerald80 = Color(0xFFA7F3D0)

val AcademyBlue40 = Color(0xFF1E3A8A)
val AcademyAmber40 = Color(0xFFD97706)
val AcademyEmerald40 = Color(0xFF047857)

val DarkSurface = Color(0xFF0F172A)
val DarkBackground = Color(0xFF0B1120)
val DarkCard = Color(0xFF1E293B)

val LightSurface = Color(0xFFFFFFFF)
val LightBackground = Color(0xFFF8FAFC)
val LightCard = Color(0xFFFFFFFF)
