package com.example.science

import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin

object ScienceEngine {

    // --- 1. PERIODIC TABLE & CHEMISTRY ---
    data class ChemicalElement(
        val atomicNumber: Int,
        val symbol: String,
        val name: String,
        val atomicMass: Double,
        val category: String, // "Nonmetal", "Noble Gas", "Alkali Metal", "Transition Metal", etc.
        val electronConfig: String,
        val colorHex: String
    )

    val elements: List<ChemicalElement> = listOf(
        ChemicalElement(1, "H", "Hydrogen", 1.008, "Reactive Nonmetal", "1s¹", "#3B82F6"),
        ChemicalElement(2, "He", "Helium", 4.0026, "Noble Gas", "1s²", "#8B5CF6"),
        ChemicalElement(3, "Li", "Lithium", 6.94, "Alkali Metal", "2s¹", "#EF4444"),
        ChemicalElement(4, "Be", "Beryllium", 9.0122, "Alkaline Earth Metal", "2s²", "#F59E0B"),
        ChemicalElement(5, "B", "Boron", 10.81, "Metalloid", "2s² 2p¹", "#10B981"),
        ChemicalElement(6, "C", "Carbon", 12.011, "Reactive Nonmetal", "2s² 2p²", "#3B82F6"),
        ChemicalElement(7, "N", "Nitrogen", 14.007, "Reactive Nonmetal", "2s² 2p³", "#3B82F6"),
        ChemicalElement(8, "O", "Oxygen", 15.999, "Reactive Nonmetal", "2s² 2p⁴", "#3B82F6"),
        ChemicalElement(9, "F", "Fluorine", 18.998, "Halogen", "2s² 2p⁵", "#06B6D4"),
        ChemicalElement(10, "Ne", "Neon", 20.180, "Noble Gas", "2s² 2p⁶", "#8B5CF6"),
        ChemicalElement(11, "Na", "Sodium", 22.990, "Alkali Metal", "[Ne] 3s¹", "#EF4444"),
        ChemicalElement(12, "Mg", "Magnesium", 24.305, "Alkaline Earth Metal", "[Ne] 3s²", "#F59E0B"),
        ChemicalElement(13, "Al", "Aluminum", 26.982, "Post-Transition Metal", "[Ne] 3s² 3p¹", "#6B7280"),
        ChemicalElement(14, "Si", "Silicon", 28.085, "Metalloid", "[Ne] 3s² 3p²", "#10B981"),
        ChemicalElement(15, "P", "Phosphorus", 30.974, "Reactive Nonmetal", "[Ne] 3s² 3p³", "#3B82F6"),
        ChemicalElement(16, "S", "Sulfur", 32.06, "Reactive Nonmetal", "[Ne] 3s² 3p⁴", "#3B82F6"),
        ChemicalElement(17, "Cl", "Chlorine", 35.45, "Halogen", "[Ne] 3s² 3p⁵", "#06B6D4"),
        ChemicalElement(18, "Ar", "Argon", 39.948, "Noble Gas", "[Ne] 3s² 3p⁶", "#8B5CF6"),
        ChemicalElement(19, "K", "Potassium", 39.098, "Alkali Metal", "[Ar] 4s¹", "#EF4444"),
        ChemicalElement(20, "Ca", "Calcium", 40.078, "Alkaline Earth Metal", "[Ar] 4s²", "#F59E0B"),
        ChemicalElement(26, "Fe", "Iron", 55.845, "Transition Metal", "[Ar] 3d⁶ 4s²", "#E11D48"),
        ChemicalElement(29, "Cu", "Copper", 63.546, "Transition Metal", "[Ar] 3d¹⁰ 4s¹", "#D97706"),
        ChemicalElement(30, "Zn", "Zinc", 65.38, "Transition Metal", "[Ar] 3d¹⁰ 4s²", "#4B5563"),
        ChemicalElement(35, "Br", "Bromine", 79.904, "Halogen", "[Ar] 3d¹⁰ 4s² 4p⁵", "#06B6D4"),
        ChemicalElement(47, "Ag", "Silver", 107.87, "Transition Metal", "[Kr] 4d¹⁰ 5s¹", "#9CA3AF"),
        ChemicalElement(79, "Au", "Gold", 196.97, "Transition Metal", "[Xe] 4f¹⁴ 5d¹⁰ 6s¹", "#F59E0B"),
        ChemicalElement(80, "Hg", "Mercury", 200.59, "Transition Metal", "[Xe] 4f¹⁴ 5d¹⁰ 6s²", "#64748B"),
        ChemicalElement(92, "U", "Uranium", 238.03, "Actinide", "[Rn] 5f³ 6d¹ 7s²", "#10B981")
    )

    fun calculateMolarMass(formula: String): Pair<Double, Map<String, Double>> {
        val elementMasses = elements.associate { it.symbol to it.atomicMass }
        val counts = mutableMapOf<String, Int>()

        val regex = Regex("([A-Z][a-z]?)([0-9]*)")
        val matches = regex.findAll(formula.trim())

        for (match in matches) {
            val symbol = match.groupValues[1]
            val countStr = match.groupValues[2]
            val count = if (countStr.isEmpty()) 1 else countStr.toIntOrNull() ?: 1
            counts[symbol] = (counts[symbol] ?: 0) + count
        }

        var totalMass = 0.0
        val breakdown = mutableMapOf<String, Double>()
        for ((sym, count) in counts) {
            val mass = elementMasses[sym] ?: when (sym) {
                "H" -> 1.008
                "C" -> 12.011
                "N" -> 14.007
                "O" -> 15.999
                "Na" -> 22.99
                "Cl" -> 35.45
                "S" -> 32.06
                "K" -> 39.10
                "Ca" -> 40.08
                else -> 1.0
            }
            val subtotal = mass * count
            totalMass += subtotal
            breakdown[sym] = subtotal
        }

        return Pair(totalMass, breakdown)
    }

    fun calculatePH(hConcentration: Double): Triple<Double, Double, String> {
        val ph = if (hConcentration > 0) -log10(hConcentration) else 7.0
        val poh = 14.0 - ph
        val type = when {
            ph < 6.8 -> "Acidic (Excess H⁺ hydronium)"
            ph > 7.2 -> "Basic / Alkaline (Excess OH⁻ hydroxide)"
            else -> "Neutral (pH ≈ 7.0 at 25°C)"
        }
        return Triple(ph, poh, type)
    }

    // --- 2. PHYSICS KINEMATICS & CIRCUITS ---
    data class KinematicsResult(
        val finalVelocity: Double, // v = u + at
        val displacement: Double,  // d = ut + 0.5 a t^2
        val avgVelocity: Double,
        val kineticEnergyPerKg: Double // 0.5 * v^2
    )

    fun solveKinematics(initialVelocity: Double, acceleration: Double, time: Double): KinematicsResult {
        val v = initialVelocity + (acceleration * time)
        val d = (initialVelocity * time) + (0.5 * acceleration * time.pow(2))
        val avgV = (initialVelocity + v) / 2.0
        val ke = 0.5 * v.pow(2)
        return KinematicsResult(v, d, avgV, ke)
    }

    data class CircuitResult(
        val voltage: Double,
        val current: Double,
        val resistance: Double,
        val powerWatts: Double
    )

    fun solveOhmsLaw(voltage: Double?, current: Double?, resistance: Double?): CircuitResult {
        var v = voltage ?: 0.0
        var i = current ?: 0.0
        var r = resistance ?: 0.0

        if (voltage != null && current != null) {
            r = if (i != 0.0) v / i else 0.0
        } else if (voltage != null && resistance != null) {
            i = if (r != 0.0) v / r else 0.0
        } else if (current != null && resistance != null) {
            v = i * r
        }

        val p = v * i
        return CircuitResult(v, i, r, p)
    }

    // --- 3. BIOLOGY GENETICS & CENTRAL DOGMA ---
    data class PunnettResult(
        val parent1Alleles: String,
        val parent2Alleles: String,
        val grid: List<List<String>>, // 2x2
        val genotypicRatio: String,
        val phenotypicRatio: String
    )

    fun calculatePunnettSquare(parent1: String, parent2: String): PunnettResult {
        val p1 = parent1.trim().padEnd(2, 'a').take(2)
        val p2 = parent2.trim().padEnd(2, 'a').take(2)

        val row1 = listOf("${p1[0]}${p2[0]}", "${p1[0]}${p2[1]}")
        val row2 = listOf("${p1[1]}${p2[0]}", "${p1[1]}${p2[1]}")

        val standardOffspring = listOf(
            standardizeGenotype(row1[0]),
            standardizeGenotype(row1[1]),
            standardizeGenotype(row2[0]),
            standardizeGenotype(row2[1])
        )

        val counts = standardOffspring.groupingBy { it }.eachCount()
        val genoStr = counts.entries.joinToString(" : ") { "${it.value} ${it.key}" }

        val dominantCount = standardOffspring.count { it.any { c -> c.isUpperCase() } }
        val recessiveCount = 4 - dominantCount
        val phenoStr = "$dominantCount Dominant : $recessiveCount Recessive"

        return PunnettResult(p1, p2, listOf(row1, row2), genoStr, phenoStr)
    }

    private fun standardizeGenotype(g: String): String {
        return if (g.length == 2 && g[0].isLowerCase() && g[1].isUpperCase()) {
            "${g[1]}${g[0]}"
        } else g
    }

    fun transcribeAndTranslateDna(dna: String): Pair<String, List<String>> {
        val cleanDna = dna.uppercase().replace(Regex("[^ATCG]"), "")
        val mrna = cleanDna
            .replace('A', 'U')
            .replace('T', 'A')
            .replace('C', 'X')
            .replace('G', 'C')
            .replace('X', 'G')

        val codons = mrna.chunked(3)
        val aminoAcids = codons.map { codonToAminoAcid(it) }
        return Pair(mrna, aminoAcids)
    }

    private fun codonToAminoAcid(codon: String): String {
        return when (codon) {
            "AUG" -> "Met (Start)"
            "UUU", "UUC" -> "Phe (Phenylalanine)"
            "UUA", "UUG", "CUU", "CUC", "CUA", "CUG" -> "Leu (Leucine)"
            "AUU", "AUC", "AUA" -> "Ile (Isoleucine)"
            "GUU", "GUC", "GUA", "GUG" -> "Val (Valine)"
            "UCU", "UCC", "UCA", "UCG" -> "Ser (Serine)"
            "CCU", "CCC", "CCA", "CCG" -> "Pro (Proline)"
            "ACU", "ACC", "ACA", "ACG" -> "Thr (Threonine)"
            "GCU", "GCC", "GCA", "GCG" -> "Ala (Alanine)"
            "UAU", "UAC" -> "Tyr (Tyrosine)"
            "UAA", "UAG", "UGA" -> "STOP"
            "CAU", "CAC" -> "His (Histidine)"
            "CAA", "CAG" -> "Gln (Glutamine)"
            "AAU", "AAC" -> "Asn (Asparagine)"
            "AAA", "AAG" -> "Lys (Lysine)"
            "GAU", "GAC" -> "Asp (Aspartate)"
            "GAA", "GAG" -> "Glu (Glutamate)"
            "UGU", "UGC" -> "Cys (Cysteine)"
            "UGG" -> "Trp (Tryptophan)"
            "CGU", "CGC", "CGA", "CGG", "AGA", "AGG" -> "Arg (Arginine)"
            "GGU", "GGC", "GGA", "GGG" -> "Gly (Glycine)"
            else -> "Unknown ($codon)"
        }
    }
}
