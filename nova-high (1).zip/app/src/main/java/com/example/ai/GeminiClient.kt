package com.example.ai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    fun getApiKey(): String {
        return try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * 1. Deep Thinking STEM Solver using gemini-3.1-pro-preview
     * thinkingLevel = HIGH, do not set maxOutputTokens
     */
    suspend fun generateDeepThinking(prompt: String): Pair<String, String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Pair(
                "Thinking Process:\n- Identified physics/chemistry principles.\n- Extracted given variables and boundary conditions.\n- Computed theoretical equations.",
                "Demo Solution: For the problem '$prompt':\n1. Formulate fundamental conservation laws: Sum(F) = ma or Delta(G) = Delta(H) - T*Delta(S).\n2. Substitute measured variables.\n3. Result: Exact analytical solution derived successfully.\n\n(Tip: Enter your GEMINI_API_KEY in the AI Studio secrets panel for live high-thinking inferences!)"
            )
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        })
                    })
                }
                put("contents", contents)

                val genConfig = JSONObject().apply {
                    val thinkingConfig = JSONObject().apply {
                        put("thinkingLevel", "HIGH")
                    }
                    put("thinkingConfig", thinkingConfig)
                }
                put("generationConfig", genConfig)
            }

            val url = "$BASE_URL/models/gemini-3.1-pro-preview:generateContent?key=$apiKey"
            val body = root.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext Pair("Error: HTTP ${response.code}", responseBody)
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            var thinkingText = ""
            var answerText = ""

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.optBoolean("thought", false)) {
                        thinkingText += part.optString("text") + "\n"
                    } else {
                        val text = part.optString("text", "")
                        if (text.isNotBlank()) {
                            answerText += text
                        }
                    }
                }
            }

            if (answerText.isBlank() && thinkingText.isNotBlank()) {
                answerText = thinkingText
                thinkingText = "Thinking completed."
            }

            Pair(thinkingText.trim(), if (answerText.isNotBlank()) answerText.trim() else "No text response received.")
        } catch (e: Exception) {
            Log.e(TAG, "generateDeepThinking failed", e)
            Pair("Exception occurred: ${e.message}", "Could not complete deep thinking query. Check connectivity.")
        }
    }

    /**
     * 2. General task or fast response
     * gemini-3.5-flash for general, gemini-3.1-flash-lite for fast
     */
    suspend fun generateText(prompt: String, fastMode: Boolean = false): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        val model = if (fastMode) "gemini-3.1-flash-lite" else "gemini-3.5-flash"

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext if (fastMode) {
                "Quick Study Insight ($model):\n• Core Concept: Master the fundamentals first.\n• Key Formula: E = mc² or PV = nRT.\n• Pro-tip: Active recall boosts retention by 60%."
            } else {
                "Academic Tutor ($model):\nHere is a comprehensive breakdown for: $prompt.\nHigh school curricula emphasize conceptual understanding, multi-step derivation, and real-world application."
            }
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        })
                    })
                }
                put("contents", contents)
            }

            val url = "$BASE_URL/models/$model:generateContent?key=$apiKey"
            val body = root.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext "Error ${response.code}: $responseBody"
            }

            val jsonResponse = JSONObject(responseBody)
            val text = jsonResponse.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text")

            text ?: "No text returned from Gemini."
        } catch (e: Exception) {
            Log.e(TAG, "generateText failed", e)
            "Error: ${e.localizedMessage}"
        }
    }

    /**
     * 3. Google Search Grounding with gemini-3.5-flash
     */
    suspend fun searchGrounding(query: String): Pair<String, List<String>> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Pair(
                "Search Grounding Demo: Up-to-date college admission guidelines and AP Science exam schedule for 2026-2027 indicate AP Chem on May 4 and AP Physics C on May 11.",
                listOf("https://apstudents.collegeboard.org", "https://khanacademy.org/science")
            )
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", query) })
                        })
                    })
                }
                put("contents", contents)

                val tools = JSONArray().apply {
                    put(JSONObject().apply {
                        put("googleSearch", JSONObject())
                    })
                }
                put("tools", tools)
            }

            val url = "$BASE_URL/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val body = root.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext Pair("Error ${response.code}: $responseBody", emptyList())
            }

            val json = JSONObject(responseBody)
            val firstCandidate = json.optJSONArray("candidates")?.optJSONObject(0)
            val text = firstCandidate?.optJSONObject("content")
                ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text") ?: "No content"

            val sources = mutableListOf<String>()
            val groundingMetadata = firstCandidate?.optJSONObject("groundingMetadata")
            val searchChunks = groundingMetadata?.optJSONArray("groundingChunks")
            if (searchChunks != null) {
                for (i in 0 until searchChunks.length()) {
                    val web = searchChunks.optJSONObject(i)?.optJSONObject("web")
                    val uri = web?.optString("uri")
                    if (!uri.isNullOrBlank()) sources.add(uri)
                }
            }

            Pair(text, sources)
        } catch (e: Exception) {
            Pair("Search Grounding exception: ${e.message}", emptyList())
        }
    }

    /**
     * 4. Google Maps Grounding with gemini-3.5-flash
     */
    suspend fun mapsGrounding(query: String): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Maps Grounding Demo: Found recommended science learning locations:\n1. City Science Center & Planetarium (2.4 mi)\n2. Central Public Library STEM Lab (1.1 mi)\n3. State University Physics Department open observatory (4.8 mi)"
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", query) })
                        })
                    })
                }
                put("contents", contents)

                val tools = JSONArray().apply {
                    put(JSONObject().apply {
                        put("googleMaps", JSONObject())
                    })
                }
                put("tools", tools)
            }

            val url = "$BASE_URL/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val body = root.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext "Error ${response.code}: $responseBody"
            }

            val json = JSONObject(responseBody)
            val text = json.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
            text ?: "No maps details retrieved."
        } catch (e: Exception) {
            "Maps Grounding exception: ${e.message}"
        }
    }

    /**
     * 5. High-Quality Image Generation with gemini-3-pro-image-preview
     * Size affordance: 1K, 2K, 4K
     */
    suspend fun generateHighQualityImage(prompt: String, imageSize: String = "1K"): Pair<String?, String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Pair(null, "Demo: Generated high-definition scientific visual for '$prompt' at $imageSize resolution. (Configure GEMINI_API_KEY for live rendering).")
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        })
                    })
                }
                put("contents", contents)

                val genConfig = JSONObject().apply {
                    val imgConfig = JSONObject().apply {
                        put("aspectRatio", "1:1")
                        put("imageSize", imageSize)
                    }
                    put("imageConfig", imgConfig)
                    put("responseModalities", JSONArray().apply {
                        put("TEXT")
                        put("IMAGE")
                    })
                }
                put("generationConfig", genConfig)
            }

            val url = "$BASE_URL/models/gemini-3-pro-image-preview:generateContent?key=$apiKey"
            val body = root.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext Pair(null, "Image generation error: HTTP ${response.code}: $responseBody")
            }

            val json = JSONObject(responseBody)
            val parts = json.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")

            var base64Data: String? = null
            var textDescription = ""

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("inlineData")) {
                        base64Data = p.getJSONObject("inlineData").optString("data")
                    } else if (p.has("text")) {
                        textDescription += p.optString("text") + " "
                    }
                }
            }

            Pair(base64Data, if (textDescription.isNotBlank()) textDescription.trim() else "Image generated successfully at $imageSize.")
        } catch (e: Exception) {
            Pair(null, "Image generation failed: ${e.message}")
        }
    }

    /**
     * 6. Convert Text to Speech (TTS) using gemini-3.8-flash-tts
     */
    suspend fun generateTTS(textToSpeak: String, voice: String = "Puck"): ByteArray? = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext null
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", textToSpeak) })
                        })
                    })
                }
                put("contents", contents)

                val genConfig = JSONObject().apply {
                    put("responseModalities", JSONArray().apply { put("AUDIO") })
                    val speechConfig = JSONObject().apply {
                        val voiceConfig = JSONObject().apply {
                            val prebuiltVoiceConfig = JSONObject().apply {
                                put("voiceName", voice)
                            }
                            put("prebuiltVoiceConfig", prebuiltVoiceConfig)
                        }
                        put("voiceConfig", voiceConfig)
                    }
                    put("speechConfig", speechConfig)
                }
                put("generationConfig", genConfig)
            }

            val url = "$BASE_URL/models/gemini-3.8-flash-tts:generateContent?key=$apiKey"
            val body = root.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (!response.isSuccessful) return@withContext null

            val json = JSONObject(responseBody)
            val parts = json.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.has("inlineData")) {
                        val inline = part.getJSONObject("inlineData")
                        val base64 = inline.optString("data")
                        return@withContext Base64.decode(base64, Base64.DEFAULT)
                    }
                }
            }
            null
        } catch (e: Exception) {
            Log.e(TAG, "generateTTS failed", e)
            null
        }
    }

    /**
     * 7. Generate Music using lyria-3-clip-preview (<=30s) or lyria-3-pro-preview (full track)
     */
    suspend fun generateMusic(musicPrompt: String, fullLength: Boolean = false): Pair<ByteArray?, String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        val model = if (fullLength) "lyria-3-pro-preview" else "lyria-3-clip-preview"

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Pair(
                null,
                "Demo Music Synthesizer: Focus Lo-Fi Study Beats ($model) - 120BPM soothing ambient chords synthesized for high-focus STEM learning session."
            )
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", musicPrompt) })
                        })
                    })
                }
                put("contents", contents)

                val genConfig = JSONObject().apply {
                    put("responseModalities", JSONArray().apply { put("AUDIO") })
                }
                put("generationConfig", genConfig)
            }

            val url = "$BASE_URL/models/$model:generateContent?key=$apiKey"
            val body = root.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext Pair(null, "Music generation error: HTTP ${response.code}: $responseBody")
            }

            val json = JSONObject(responseBody)
            val parts = json.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")

            var audioBytes: ByteArray? = null
            var note = "Music generated successfully using $model."

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("inlineData")) {
                        val b64 = p.getJSONObject("inlineData").optString("data")
                        audioBytes = Base64.decode(b64, Base64.DEFAULT)
                    } else if (p.has("text")) {
                        note = p.optString("text")
                    }
                }
            }

            Pair(audioBytes, note)
        } catch (e: Exception) {
            Pair(null, "Music generation failed: ${e.message}")
        }
    }

    /**
     * 8. Animate Image into Video using veo-3.1-fast-generate-preview
     * Aspect ratio 16:9 or 9:16
     */
    suspend fun generateVideo(prompt: String, aspectRatio: String = "16:9"): Pair<String?, String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Pair(
                null,
                "Demo Video Generation: Initialized Veo animation task for '$prompt' with aspect ratio $aspectRatio. Video frames rendered into scientific simulation sequence."
            )
        }

        try {
            val root = JSONObject().apply {
                put("prompt", prompt)
                val config = JSONObject().apply {
                    put("aspectRatio", aspectRatio)
                    put("numberOfVideos", 1)
                    put("resolution", "720p")
                }
                put("config", config)
            }

            val url = "$BASE_URL/models/veo-3.1-fast-generate-preview:generateVideos?key=$apiKey"
            val body = root.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                return@withContext Pair(null, "Veo Video error: HTTP ${response.code}: $responseBody")
            }

            val json = JSONObject(responseBody)
            val opName = json.optString("name", "Operation started")
            Pair(opName, "Veo Video generation in progress ($aspectRatio). Operation: $opName")
        } catch (e: Exception) {
            Pair(null, "Veo generation failed: ${e.message}")
        }
    }

    /**
     * 9. Voice Conversation with gemini-3.8-live
     */
    suspend fun liveVoiceConversation(userUtterance: String, conversationHistory: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Nova Voice Tutor (gemini-3.8-live): I heard you ask '$userUtterance'. Let's break this down conceptually together! What specific variable or theorem would you like to explore first?"
        }

        try {
            val root = JSONObject().apply {
                val contents = JSONArray().apply {
                    for ((role, text) in conversationHistory) {
                        put(JSONObject().apply {
                            put("role", if (role == "user") "user" else "model")
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply { put("text", text) })
                            })
                        })
                    }
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", userUtterance) })
                        })
                    })
                }
                put("contents", contents)

                val systemInstruction = JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "You are Nova, an engaging, supportive, and brilliant high school STEM and academic coach speaking directly to a student in a live voice conversation session. Keep responses conversational, concise, insightful, and encouraging.")
                        })
                    })
                }
                put("systemInstruction", systemInstruction)
            }

            val url = "$BASE_URL/models/gemini-3.8-live:generateContent?key=$apiKey"
            val body = root.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                // Fallback to gemini-3.5-flash if live model endpoint requires preview header
                val fallbackUrl = "$BASE_URL/models/gemini-3.5-flash:generateContent?key=$apiKey"
                val fallbackRequest = Request.Builder().url(fallbackUrl).post(body).build()
                val fallbackResponse = okHttpClient.newCall(fallbackRequest).execute()
                val fallbackBody = fallbackResponse.body?.string() ?: ""
                val fallbackJson = JSONObject(fallbackBody)
                return@withContext fallbackJson.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                    ?: "Voice session response received."
            }

            val json = JSONObject(responseBody)
            val reply = json.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
            reply ?: "Hello! How can I assist with your science or high school studies today?"
        } catch (e: Exception) {
            "Voice Tutor error: ${e.message}"
        }
    }
}
